<?php echo $view['form']->renderBlock('field_rows') ?>
