<?php echo $view['form']->renderBlock('field_widget',  array('type' => isset($type) ? $type : "password")) ?>
