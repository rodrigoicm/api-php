<?php echo $view['form']->widget($form) ?>
