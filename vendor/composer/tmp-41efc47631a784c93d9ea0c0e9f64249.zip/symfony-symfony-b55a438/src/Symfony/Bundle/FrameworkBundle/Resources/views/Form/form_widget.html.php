<div <?php echo $view['form']->renderBlock('container_attributes') ?>>
    <?php echo $view['form']->renderBlock('field_rows') ?>
    <?php echo $view['form']->rest($form) ?>
</div>

